This program contents
- task.txt
- completed.txt
- README.md
- task(obj file)

Demo of program: https://youtu.be/CNCsFNLYb8Q

Usage 
./task 
./task help
./task del [index]
./task ls
./task add [priority number] ["task"]
./task report


All above program method can be call through command line...

Thank you!